def formatRow(arr):
    """
    Formats row in latex way
    """
    return ' ' * 4 + ' & '.join(arr)
